using System;
using System.IO;

public class Program
{
  public static void Main()
  {
    double sum = 0, averageTemperature = 0, temperature;
    string line;
    int count = 0;

    using (StreamReader reader = new StreamReader(new FileStream("data.txt", FileMode.Open)))
    {
      line = reader.ReadLine();
      while (line != null)
      {
        count++;

        temperature = Convert.ToDouble(line);
        sum = sum + temperature;
        Console.WriteLine("line " + count + " has a temperature of: " + temperature);

        line = reader.ReadLine();
      }
      averageTemperature = sum / count;
      Console.WriteLine("\nThe average temperature is: " + averageTemperature);
    }
  }
}
