using System;
using System.IO;

public class Program
{
  public static void Main()
  {
    double sum = 0, averageTemperature = 0, temperature;
    string line;
    int count = 0, errors = 0;

    try
    {
      using (StreamReader reader = new StreamReader(new FileStream("dataa.txt", FileMode.Open)))
      {
        line = reader.ReadLine();
        while (line != null)
        {
          count++;
          try
          {
            temperature = Convert.ToDouble(line);
            sum = sum + temperature;
            Console.WriteLine("line " + count + " has a temperature of: " + temperature);
          }
          catch (Exception e)
          {
            errors++;
            // Let the user knowls what went wrong.
            Console.Write("Error on line " + count + ": ");
            Console.WriteLine(e.Message);
          }
          line = reader.ReadLine();
        }
        averageTemperature = sum / (count - errors);
        Console.WriteLine("\nThe average temperature is: " + averageTemperature);
        Console.WriteLine(errors + " error/s in the data");
      }
    }
    catch
    {
      Console.WriteLine("Unable to open file");
    }
  }
}
