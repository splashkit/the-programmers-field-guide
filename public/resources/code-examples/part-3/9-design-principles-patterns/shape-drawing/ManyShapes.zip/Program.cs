using SplashKitSDK;

namespace ShapeDrawer
{
  public class Program
  {
    public static void Main()
    {

      //Open a new Graphics Window
      Window window = new Window("Shape Drawer", 800, 600);

      Drawing myDrawing = new Drawing();

      //Create and add a Shape
      Shape s;
      Point2D p;

      s = new Shape();
      s.Color = Color.Blue;
      s.Width = 30;
      s.Height = 50;
      p = new Point2D();
      p.X = 75;
      p.Y = 25;
      s.Position = p;

      myDrawing.AddShape(s);

      //Game Loop
      do
      {
        SplashKit.ProcessEvents();

        window.Clear(Color.White);

        myDrawing.Draw();

        window.Refresh();
      } while (!window.CloseRequested);
    }
  }
}
