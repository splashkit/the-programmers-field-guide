#include "utilities.h"
#include "splashkit.h"
using std::to_string;
using std::stoi;

string read_string(string prompt)
{
    write(prompt);
    return read_line();
}

int read_integer(string prompt)
{
    string input = read_string(prompt);
    while (!is_integer(input))
    {
        write_line("Please enter a whole number.");
        input = read_string(prompt);
    }
    return stoi(input);
}
int read_integer(string prompt, int low, int high)
{
    int input = read_integer(prompt);
    while (input < low || input > high)
    {
        write_line("Please enter a value between " + to_string(low) + " " + to_string(high));
        input = read_integer(prompt);
    }
    return input;
}
