#ifndef UTILITIES_H
#include "splashkit.h"

// Prints prompt and returns whatever is entered by the user (including potentially nothing)
string read_string(string prompt);

// Prints prompt and returns a valid integer entered by the user
int read_integer(string prompt);

// Prints prompt and returns a valid integer entered by the user between min and max
int read_integer(string prompt, int min, int max);
// Alias
int read_integer_range(string prompt, int min, int max);

// Prints prompt and returns a valid double entered by the user
double read_double(string prompt);

// Prints prompt and returns a valid boolean entered by the user (y/Y/n/N)
bool read_boolean(string prompt);

inline string read_string(string prompt)
{
    write(prompt);
    return read_line();
}

inline int read_integer(string prompt)
{
    string input = read_string(prompt);

    while (!is_integer(input))
    {
        write_line("Please enter a whole number :)");
        input = read_string(prompt);
    }

    return to_integer(input);
}

inline int read_integer(string prompt, int min ,int max)
{
    int input = read_integer(prompt);

    while (!(input >= min && input <= max))
    {
        write_line("Please enter a number between " + to_string(min) + " and " + to_string(max) + " :)");
        input = read_integer(prompt);
    }

    return input;
}

inline int read_integer_range(string prompt, int min ,int max)
{
    return read_integer(prompt, min, max);
}

inline double read_double(string prompt)
{
    string input = read_string(prompt);

    while (!is_number(input))
    {
        write_line("Please enter a number :)");
        input = read_string(prompt);
    }

    return to_double(input);
}

inline bool read_boolean(string prompt)
{
    string input = to_lowercase(read_string(prompt));

    while (!(input == "y" || input == "n"))
    {
        write_line("Please enter y or n, thanks!");
        input = to_lowercase(read_string(prompt));
    }

    return input == "y";
}

#endif //UTILITIES_H
