You can place scripts for animations in this folder.

SplashKit Animation

//Multi-frame: ranges are in[]
//[a-b] = numbers from a to b inclusive
//[a,b,c] = explicit values
//[a-b,c] = combination